#!/bin/bash
sleep 5s
killall conky
cd "/home/$(whoami)/conky/ConkyWhiteTilesv2"
conky -c "/home/$(whoami)/.conky/ConkyWhiteTilesv2/temp" &
cd "/home/$(whoami)/conky/Gold&Grey"
conky -c "/home/$(whoami)/.conky/Gold&Grey/cpu" &
cd "/home/$(whoami)/conky/Gold&Grey"
conky -c "/home/$(whoami)/.conky/Gold&Grey/disk" &
cd "/home/$(whoami)/conky/Gold&Grey"
conky -c "/home/$(whoami)/.conky/Gold&Grey/mem" &
cd "/home/$(whoami)/conky/Gold&Grey"
conky -c "/home/$(whoami)/.conky/Gold&Grey/net" &
cd "/home/$(whoami)/conky/TeejeeTech"
conky -c "/home/$(whoami)/.conky/TeejeeTech/CPU Panel (8-core)" &
cd "/home/$(whoami)/conky/TeejeeTech"
conky -c "/home/$(whoami)/.conky/TeejeeTech/Network Panel" &
cd "/home/$(whoami)/conky/TeejeeTech"
conky -c "/home/$(whoami)/.conky/TeejeeTech/Process Panel" &
cd "/home/$(whoami)/conky/ULogo4C"
conky -c "/home/$(whoami)/.conky/ULogo4C/Ubuntu-Quad-Core-conkyrc" &

exit 0
